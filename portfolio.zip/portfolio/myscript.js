const menu=document.querySelector("#menu");
const nav=document.querySelector(".nav-bar");
menu.onclick = () =>{
 menu.classlist.toggle('bx-x');
 nav.classlist.toggle('active');
}